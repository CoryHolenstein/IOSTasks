import https from 'https';

let jwksCache = {};
let cacheExpiry = 0;

async function getJWKS() {
  const now = Date.now();
  
  if (jwksCache.keys && cacheExpiry > now) {
    return jwksCache;
  }

  return new Promise((resolve, reject) => {
    https.get('https://dev-3bogxk1spsq5do2v.us.auth0.com/.well-known/jwks.json', (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          jwksCache = JSON.parse(data);
          cacheExpiry = now + (3600 * 1000);
          resolve(jwksCache);
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

export const handler = async (event) => {
  try {
    console.log('Authorizing request');
    
    const authHeader = event.headers?.authorization || '';
    const token = authHeader.replace('Bearer ', '');
    
    if (!token) {
      console.log('No token found');
      return { isAuthorized: false };
    }

    const parts = token.split('.');
    
    if (parts.length === 5 || parts.length === 3) {
      // JWE (5 parts) or JWT (3 parts) - Auth0 already validated on iOS
      console.log(`Auth0 token detected (${parts.length === 5 ? 'encrypted JWE' : 'JWT'})`);
      
      return {
        isAuthorized: true,
        context: {
          userId: 'auth0-user',
          tokenType: parts.length === 5 ? 'JWE' : 'JWT'
        }
      };
    }

    console.log('Invalid token format');
    return { isAuthorized: false };

  } catch (error) {
    console.error('Auth error:', error.message);
    return { isAuthorized: false };
  }
};